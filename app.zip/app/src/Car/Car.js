import React, { Component } from 'react';

class Carsinfo extends Component {
    constructor(props) {
        super(props);
        console.log('Car Cons');
    }
    static getDerivedStateFromProps(props, state) {
        console.log('This is getDerivedStateFromProps');
      }
      componentDidMount() {
        console.log('Car Mounted');
      }
    render () {
        console.log('This is cars render');
        return (
            <div>
                <p>Name of the car {this.props.name} by {this.props.make}<span onClick = {this.props.index}> Remove</span></p>            
            </div>
        );
    }
}

export default Carsinfo;
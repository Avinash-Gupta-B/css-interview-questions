import React, { Component } from 'react';

class ErrorBoundaries extends Component {
 state = {
     hasError: false,
     errorMsg: ''
 }
    
componentDidCatch(error, info) {
    console.log(error);
    this.setState({hasError: true, errorMsg: 'error'});
}

render() {

    if(this.state.hasError) {
    return (
        <div><h1>Error triggered</h1><br/><p>{this.state.errorMsg}</p></div>
    );
    }

    return this.props.children;
}


}


export default ErrorBoundaries;
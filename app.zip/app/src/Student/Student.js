import React, { Component } from 'react';
import './Student.css';

class Student extends Component {

    constructor(props) {
        super(props);
        console.log("Student Cons")
    }

    /*  static getDerivedStateFromProps(props, state) {
        console.log('StudentgetDerivedStateFromProps');
    }*/

    shouldComponentUpdate(nextProps, nextState) {
        console.log('Student Update');
        console.log('Student Update-->'+this.props.name);
        if(this.props.name != nextProps.name) {
            return true;
        }else {
            return false;
        }
     //   return true;
      }
    
      getSnapshotBeforeUpdate(prevProps, prevState) {
        console.log('Student SnapShot');
        return ({"day": "student day"});
      }
    
      componentDidUpdate(prevProps, prevState, snapShot) {
        console.log('Student Did Update');
        // If required we cam call http requests, callback methods we should set state  
      }

      componentDidMount() {
          // If required we cam call http requests, callback methods we should set state  
          console.log('Student Did Mount');
      }
    render() {
        console.log("Student render");
        return (
            <div className = "sam">
        <p onClick={this.props.clickfun}>My name is {this.props.name} and Roll number is {this.props.num} </p>
        <span>{this.props.children}</span>
        <input type="text" onChange = {this.props.change} value = {this.props.name}/>
        </div>
        );
    }
}

export default Student;
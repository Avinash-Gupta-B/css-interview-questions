import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Student from './Student/Student';
import Carsinfo from './Car/Car';
import ErrorBoundaries from './Error/ErrorBoundaries';

class App extends Component {

  constructor(props) {
    super(props);
    console.log('This is constr');
    this.state = {
      name: 'Ram',
      num: 12345,
      load: false,
      names: 'qw',
      cars: [{ id: 12, name: "Amaze", make: "Honda" },
      { id: 123,name: "civic", make: "Honda" },
      { id: 1234, name: "Ameo", make: "VW" },
      { id: 12345, name: "Rapid", make: "skoda" }
      ]
    }
}

/*
static getDerivedStateFromProps(props, state) {
  console.log('This is getDerivedStateFromProps');
}*/

  sample = (param1) => {
    console.log('Hello' + this);
   /* this.setState((s, p) => ({
      names: s.param1
    }));*/
    const temp = this.state.load;
    this.setState({load: !temp});

  }

  sample2 = () => {
   // this.state.load = true;
   this.setState({load: !this.state.load});
  }

  updateName = (event) => {
    // console.log(event.target.value);
    this.setState({name: event.target.value});
  }

  removeCar(index) {
    console.log(index);
    //const temp = this.state.cars;
    //const temp = this.state.cars.slice();
    // SPREAD OPERATERS
    const temp = [...this.state.cars];
    temp.splice(index, 1);
    this.setState({cars: temp});

    // mutate
    //splice and slice

    
  }

  componentDidMount() {
    console.log('App Mounted');
    // If required we cam call http requests, callback methods we should set state
    const temp = this.state.load;
    this.setState({load: !temp});
  }

  shouldComponentUpdate(nextProps, nextState) {
    console.log('App Update');
    if(this.state.load != nextState.load) {
      return true;
  }else {
      return false;
  }
  }

  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('App SnapShot');
    return ({"day": "Friday"});
  }

  componentDidUpdate(prevProps, prevState, snapShot) {
    console.log('App Did Update');
    // If required we cam call http requests, callback methods we should set state  
  }
  
  render() {
    console.log('this is render');
    let day = null;
    if(this.state.load) {
      day = <div>Today is sunday</div>;
      
    }else {
      day = <div>No Day</div>;
    
    }

    let carInfo = null;
    carInfo = this.state.cars.map((car, index) => {
      return <ErrorBoundaries><Carsinfo name = {car.name} make = {car.make} index = {this.removeCar.bind(this, index)} key={car.id}/></ErrorBoundaries>
    });
    return (
      <div className="App">
        <div className="App-header">

        <button onClick={this.sample.bind(this, "dell")}>Click me</button>
        <button onClick={this.sample2}>Update Day</button>
          <img src={logo} className="App-logo" alt="logo" />
        <Student name={this.state.name} num='123'  change = {this.updateName}/>
        {/*<Student name='React1' num='1234'>Hello</Student>  */}
        </div>
        <br/>

        {/*conditional Div*/}

        {/*
         day*/
        }

        {/*carInfo*/}
        

      </div>
    );
  }
}

export default App;
